options ls=100 nocenter nofmterr;

libname here '.';


data one;
set here.top5clean;


if journal="AER" then journaln=1;
else if journal="EMA" then journaln=2;
else if journal="JPE" then journaln=3;
else if journal="QJE" then journaln=4;
else journaln=5;

proc summary;
class journaln year;
var lengthnorm;

output out=s1
     n(lengthnorm)=npapers
  mean(lengthnorm)=meanlength
median(lengthnorm)=medlength;

*proc print data=s1;

data one;
set s1;
if journaln=1;
aer=medlength;
keep year aer;

data two;
set s1;
if journaln=2;
ema=medlength;
keep year ema;

data three;
set s1;
if journaln=3;
jpe=medlength;
keep year jpe;

data four;
set s1;
if journaln=4;
qje=medlength;
keep year qje;

data five;
set s1;
if journaln=5;
res=medlength;
keep year res;


	

data here.medlength;
merge one two three four five;
by year;

proc print;




data dd;
set s1;
if journaln ne .;
if year ne .;

if year>=2009 then post=1;
else post=0;

trend=year-1969;
trendsq=trend*trend;
trendcu=trend*trend*trend;
aer_post=post*(journaln=1);
aer=(journaln=1);

proc means;
class journaln;

proc glm;
model meanlength=aer trend post aer_post / solution;
proc glm;
model medlength=aer trend post aer_post / solution;

proc glm;
class journaln;
model meanlength=journaln trend post aer_post / solution;
proc glm;
class journaln;
model medlength=journaln trend post aer_post / solution;

proc glm;
class journaln;
model meanlength=journaln trend trendsq post aer_post / solution;
proc glm;
class journaln;
model medlength=journaln trend trendsq post aer_post / solution;

proc glm;
class journaln year;
model meanlength=journaln year aer_post / solution;
proc glm;
class journaln year;
model medlength=journaln year aer_post / solution;
