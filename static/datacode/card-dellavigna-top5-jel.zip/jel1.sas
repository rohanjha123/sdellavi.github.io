options ls=100 nocenter nofmterr;

libname here '.';


proc freq data=here.top5clean;
tables journal;


data one;
set here.top5clean;


if journal="AER" then journaln=1;
else if journal="EMA" then journaln=2;
else if journal="JPE" then journaln=3;
else if journal="QJE" then journaln=4;
else journaln=5;

proc summary;
class journaln year;
var citations;

output out=s1
n(citations)=npapers
mean(citations)=meancites
median(citations)=medcites;

proc print data=s1;
where (journaln=.);
title2 'all';
var year npapers meancites medcites;



data s0;
set s1;
if journaln=. ;
if year ne .;

nall=npapers;
meanall=meancites;
medall=medcites;
totall=meancites*nall;
keep year nall meanall medall totall;

proc print;

data s2;
set s1;
if journaln ne .;
if year ne .;
totcites=npapers*meancites;
keep journaln year npapers meancites medcites totcites;



proc sort data=s0; by year;
proc sort data=s2; by year;

data here.relcites;
merge s2 s0 ; by year;

sharec=totcites/totall;
sharep=npapers/nall;
relshare=sharec/sharep;

proc sort; 
by journaln year;

proc print;
var journaln year npapers meancites medcites totcites sharep sharec relshare;

