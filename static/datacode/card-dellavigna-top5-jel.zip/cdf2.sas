options ls=100 nocenter nofmterr;

libname here '.';


data one;
set here.top5clean;

if journal="AER" then journaln=1;
else if journal="EMA" then journaln=2;
else if journal="JPE" then journaln=3;
else if journal="QJE" then journaln=4;
else journaln=5;


bin=floor(citations/10)+1;
binmean=10*(bin-1)+5;

if bin>101 then bin=101;

if year>=1990 and year<=2009;

c=1;


proc univariate;
var citations;

proc chart;
hbar citations / type=percent midpoints=-5 to 1000 by 10;


proc summary;
class journaln bin;
var c binmean;
output out=s1
sum(c)=f
min(binmean)=binmean;


data s0;
set s1;
if bin=.;
total=f;
keep journaln total;

proc print;

proc sort data=s0;
by journaln;


data s2;
set s1;
if bin ne .;

proc sort data=s0;
by journaln;


data s3;
merge s2 s0;
by journaln;

data s4;
set s3;
if journaln=.;

cum+f/total;
cum0=cum;
journaln=0;

proc print;
var journaln bin binmean f cum;


data k0;
set s4;
keep bin binmean cum0;



data s4;
set s3;
if journaln=1;

cum+f/total;
cum1=cum;

proc print;
var journaln bin binmean f cum;

data k1;
set s4;
keep bin binmean cum1;



data s4;
set s3;
if journaln=2;

cum+f/total;
cum2=cum;

proc print;
var journaln bin binmean f cum;

data k2;
set s4;
keep bin binmean cum2;

data s4;
set s3;
if journaln=3;

cum+f/total;
cum3=cum;

proc print;
var journaln bin binmean f cum;

data k3;
set s4;
keep bin binmean cum3;

data s4;
set s3;
if journaln=4;

cum+f/total;
cum4=cum;
proc print;
var journaln bin binmean f cum;

data k4;
set s4;
keep bin binmean cum4;


data s4;
set s3;
if journaln=5;

cum+f/total;
cum5=cum;

proc print;
var journaln bin binmean f cum;

data k5;
set s4;
keep bin binmean cum5;


proc sort data=k0; by bin;
proc sort data=k1; by bin;
proc sort data=k2; by bin;
proc sort data=k3; by bin;
proc sort data=k4; by bin;
proc sort data=k5; by bin;

data here.cdf2;
merge k0 k1 k2 k3 k4 k5; by bin;


retain lcum1 - lcum5;

if cum1 ne . then lcum1=cum1;
else cum1=lcum1;

if cum2 ne . then lcum2=cum2;
else cum2=lcum2;

if cum3 ne . then lcum3=cum3;
else cum3=lcum3;

if cum4 ne . then lcum4=cum4;
else cum4=lcum4;

if cum5 ne . then lcum5=cum5;
else cum5=lcum5;




proc print;
var bin binmean cum0-cum5;

