*table1 - uses normalized length;


options ls=130 nocenter nofmterr;

libname here '.';


data one;
set here.top5clean;

if journal="AER" then journaln=1;
else if journal="EMA" then journaln=2;
else if journal="JPE" then journaln=3;
else if journal="QJE" then journaln=4;
else journaln=5;


nocite=(citations=0);
if citations>0 then logcite=log(citations);
else logcite=.;

t=(year-1969);
tsq=t*t/10;
tcube=t*t*t/100;
tquad=t*t*t*t/1000;

d1970=(1970<=year<=1979);
d1980=(1980<=year<=1989);
d1990=(1990<=year<=1999);
d2000=(year>=2000);

cohort=1*(year<=1989)+2*(year>=1990);

post90=(cohort=2);

group0=journaln*10+cohort;
group=journaln*10+cohort;


if group=51 then group=99;
label group='journal*cohort 1-5 * 1-2, RES/80s=99';

health=healthurblaw;

micro90=micro*post90;
theory90=theory*post90;
macro90=macro*post90;
labor90=labor*post90;
metrics90=metrics*post90;
io90=io*post90;
internat90=internat*post90;
fin90=fin*post90;
pub90=pub*post90;
health90=healthurblaw*post90;
dev90=dev*post90;
hist90=hist*post90;
lab90=lab*post90;
other90=other*post90;

twoplus=(noauthors>=2);

noauthors2=noauthors;
if noauthors>5 then noauthors2=5;
label noauthors2= 'no. authors topped at 5';

noauthorsr=noauthors;
if noauthors=1 then noauthorsr=10;

*define length based on lengthnorm, but rescaled to have same mean;

olength=length;

length=lengthnorm;

 *cutoffs from newcite0 - note data are discrete so pctiles round;

clength=9*(length<=12.0392)+2*(12.0392<length<=20.1176)+3*(20.1176<length<=27.6902)
    + 4*(27.6902<length<=38.0314) + 5*(length>38.0314);

label clength='cintile of lengths 1-5';

clength2=1*(length<=12.0392)+2*(12.0392<length<=20.1176)+3*(20.1176<length<=27.6902)
    + 4*(27.6902<length<=38.0314) + 5*(length>38.0314);


journalr=journaln;

if journalr=1 then journalr=9;
label journalr='2=EC 3=JP 4=QJ 5=RE 9=AER';



nfields=micro+ theory+ macro+ labor+ metrics+ io +internat
          + fin+ pub+ healthurblaw +dev +hist +lab +other;

nfields90=nfields*(year>=1990);

if logcite ne .;

proc means;
var logcite length noauthors noauthors2;


proc glm;
title2 'col 1'; 
class group; 
model logcite= group t tsq tcube tquad /  solution;


proc glm; 
title2 'col 2'; 
class group; 
model logcite=micro theory macro labor metrics io internat
              fin pub healthurblaw dev hist lab other
              group t tsq tcube tquad / solution;

proc glm; 
title2 'col 2'; 
class group; 
model logcite=micro theory macro labor metrics io internat
              fin pub healthurblaw dev hist lab 
              group t tsq tcube tquad nfields / solution;


proc glm;
title2 'col 3';
class group clength noauthorsr;
model logcite=clength noauthorsr micro theory macro labor metrics io internat
              fin pub healthurblaw dev hist lab 
              group t tsq tcube tquad nfields / solution;


proc glm;
title2 'col 4';
class group clength noauthorsr;
model logcite=clength noauthorsr micro theory macro labor metrics io internat
              fin pub healthurblaw dev hist lab 
              micro90 theory90 macro90 labor90 metrics90 io90 internat90
              fin90 pub90 health90 dev90 hist90 lab90 
              group t tsq tcube tquad nfields nfields90 / solution;


proc sort data=one; by year;

proc univariate data=one;
var citations;
output out=pct
pctlpts=5 to 95 by 5
pctlpre=pct;
by year;

proc print data=pct;
var year pct10 pct50 pct80 pct90 pct95;

data pct2;
set pct;
keep year pct95;

proc sort data=pct2; by year;
proc sort data=one; by year;

data two;
merge one pct2; by year;

top5pct=(citations>pct95);;

proc means;
var top5pct;

proc means;
class year;
var top5pct;



proc glm;
title2 'col 5';
class group clength noauthorsr;
model top5pct=clength noauthorsr micro theory macro labor metrics io internat
              fin pub healthurblaw dev hist lab 
              group nfields t tsq tcube tquad / solution;
